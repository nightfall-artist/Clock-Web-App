document.addEventListener('DOMContentLoaded', function () {
    const forms = document.querySelectorAll('.container');
    let currentFormIndex = 0;

    function showForm(index) {
        forms.forEach((form, i) => {
            form.style.display = i === index ? 'flex' : 'none';
        });
    }

    document.querySelectorAll('.btn').forEach(button => {
        button.addEventListener('click', function () {
            if (this.classList.contains('next')) {
                currentFormIndex++;
            } else if (this.classList.contains('back')) {
                currentFormIndex--;
            }

            if (currentFormIndex < forms.length && currentFormIndex >= 0) {
                showForm(currentFormIndex);
            }
        });
    });
});
