<?php

//PHPMailer GitHub

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

// Include PHPMailer autoloader and other necessary files
require '../vendor/phpmailer/phpmailer/src/Exception.php';
require '../vendor/phpmailer/phpmailer/src/PHPMailer.php';
require '../vendor/phpmailer/phpmailer/src/SMTP.php';

require '../vendor/autoload.php';


//Create an instance; passing `true` enables exceptions
$mail = new PHPMailer(true);
$mail->SMTPDebug = 2;
$mail->Debugoutput = 'html';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Your form fields
    $name = $_POST['name'];
    $email = $_POST['email'];
    $occupation = $_POST['occupation'];
    $familiar_with_ai = $_POST['familiar_with_ai'];
    $usage_of_ai = $_POST['usage_of_ai'];
    $trust_on_ai = $_POST['trust_on_ai'];
    $ai_job = $_POST['ai_job'];
    $ai_info = $_POST['ai_info'];
    $ai_creative = $_POST['ai_creative'];
    $thoughts_on_ai = $_POST['thoughts_on_ai'];
    $ai_ethics = $_POST['ai_ethics'];
    $ai_future = $_POST['ai_future'];

    // Instantiate PHPMailer
    $mail = new PHPMailer(true);

    try {
        // Server settings
        $mail->isSMTP();
        $mail->Host = 'smtp.gmail.com'; // Your SMTP server
        $mail->SMTPAuth = true;
        $mail->Username = 'yourname@gmail.com'; // Your SMTP username
        $mail->Password = 'your password'; // Your SMTP password
        $mail->SMTPSecure = 'ssl';  
        $mail->Port = 465;

        // Recipients
        $mail->setFrom($email, $name);
        $mail->addAddress('webjsbynani@gmail.com', 'uxi.js');

        // Content
        $mail->isHTML(true);
        $mail->Subject = 'Future AI Survey Response';
        $mail->Body = "
            <p><strong>Name:</strong> $name</p>
            <p><strong>Email:</strong> $email</p>
            <p><strong>Occupation:</strong> $occupation</p>
            <p><strong>Familiar With AI:</strong> $familiar_with_ai</p>
            <p><strong>Usage Of AI:</strong> $usage_of_ai</p>
            <p><strong>Trust On AI:</strong> $trust_on_ai</p>
            <p><strong>Impact Of AI In Jobs:</strong> $ai_job</p>
            <p><strong>AI Collects Your Info, What do you say?:</strong> $ai_info</p>
            <p><strong>Is AI Creative?:</strong> $ai_creative</p>
            <p><strong>Thoughts On AI:</strong> $thoughts_on_ai</p>
            <p><strong>What Are AI Ethics?:</strong> $ai_ethics</p>
            <p><strong>Future Of AI:</strong> $ai_future</p>
        ";

        // Send email
        $mail->send();

        echo 'Message has been sent';
    } catch (Exception $e) {
        echo "Message could not be sent. Mailer Error: {$mail->ErrorInfo}";
    }
}
?>
